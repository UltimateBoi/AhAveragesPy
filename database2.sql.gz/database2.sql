PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "pricesV2" (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp INTEGER,
                        itemkey TEXT,
                        base_key TEXT,
                        unitprice REAL,
                        count INTEGER,
                        recomb INTEGER,
                        color TEXT,
                        name TEXT,
                        ench TEXT,
                        raw_item_bytes TEXT,
                        full_nbt_json TEXT
                    );
INSERT INTO pricesV2 VALUES(1,1765810835053,'FARMER_ORB.','FARMER_ORB',390000.0,1,0,NULL,'§aFarmer Orb',NULL,'H4sIAAAAAAAA/1VUyZKjRhSs7hnb3YrwcvRREzH2pS0LBAJ0mAOLxCIWSYAQXBwFlBCITSyS0Mk/4C/w1RFz8VfMN/h7HKblOdiXqqiszPfyVUXkAIBn8BAPAAAPj+AxDh9+ewBf8EWbNw8D8KaB0RvwLMUhWqQwqnvW3wMwMI9tmhqXHFVP4FEOwXs6wPAZQzGjCY2HI2IWUiOGCmcjbELSe5LGfBjOHsB3h66MryhdFWWbwgaFfYfBqipKVDUxqp/BU4OuTVuh+m7nCTybcZTDV+Txz0SMhFwyhV3r54n6UpzWGqkq3Jh9CRS/bBiqGHuWupJkCttRjMDlvJNP51sbvWgnsSxYidodKbLxbsJ5idfLpaSrNcsgL1BcLW7JK1RUnpfpsDO6vSGa2P64hFqZF+MrYy3dNO6o07xCHkN7LWdW6vo0OW5Zq4sOJ4hbekhaYzEOWOd64bVjcrNPK5qbiy0Ht7KWaaZ9xoKI6S6qpfgcaYmkMbOwpo4udFkStp5S6k5Q19Vmsb/GeusmyBP1ZkrD44Hpv4LibFngCF46eFlTp06DUzOZXL1Q0Xi1KGBS0qsJlPWNxayYl6WgmBhF2k3r4tMuO6tWmpf8Ho43YzR15HQlmOaRbXw5d7lrEWJobzWGNF36knKAsVU6Zf9k27TWnVXDerNifi7RvjExjpQlmnyZqo0TTSfmElpWdlac7ri4rceN28hbl8+Q4oXzm8GmW32lBhjX5ZQ7C5bRQaDimFWMjFpVy3RXNhrixMVSm7jn68ptW347phcl4n0pktdnP5RiOK1wc4N3+ZrniK11Iza8dQsmmU0204rrOHGbz92uVeeVuC896qgtExMyKiIiNhYdfwKLPTmt8TMhaWcJmtedGhR2acwqxpzaSkVMuLVOngqi8nDeO+vZLUhkkgu6ZhOUBZMvC9yabBJlwb6c3DmzTGlC3WfZON3MkukCD8524IeRFZ89xRYD17Cgu9aEgBTPkv3hCXyxhWmLHv5AlyKSeQWDDp4GxObg79hYFopIs9yLlrA3/bbGNOuIaeZlKfNsHEjK2cvS2rPToxyzVK89aMkRNwQvczMb94Qjpt+OE8PxEkNck54478/pQRf01DPlmo/ZSM65zp94pS9uDbfv+7mOA51tF4rbOhRnh95LCR07Vtm7vxt0wtbdbfAg25reboHDnZJ6vBwZMYcF+Tb9zMO83QEL+7ugu9/R9369bxtrFCv+H/bK7+td7vPKWa+TWErtZv+pMW2gM01dQjl4+br1sy2mEpsUSa8+7LNu2YSbaLgu6qnhKJkhbmJNnBOes+7cfv5+7lRLwkxLDok20RPXWRy8REl0wb24ln01rOPNnSwSLZMvuuVinuNONF5e3r1JWL9zMz7HPvRZMwBfhXFdprB7Bm/VokJPPfglePfpIy3nQYVgjephc0DDCkVVcWkOw6rPr2GxBz/2lBzByu+GQZ9k9bDI78Sy9dM4GMZ1CvOw/gn80PP+Fcd5NIT5sE+6Ct41Q3RGVTf89BES4Jt+7Zk1Cope9nPv4vs7kto6b2iaoQ9Znp+bprFxn8BbHWYIfN0TFrDKUDU0Kr8f5dv5a2m2aarYbxtUP73GOhgs2I023/xibLhe2bY99B5CfE/hAT1iIDEdkTPfHzEzkhhRkwCFMIQMjRNvwXMTZ6huYFb2ofz7u7/e/wrAI/hSgBmMEHgDwD8nJu9MRAYAAA==','{"i": [{"id": 397, "Count": 1, "tag": {"HideFlags": 254, "SkullOwner": {"Id": "7c019868-271d-39d6-86d9-0247f470bad9", "hypixelPopulated": 1, "Properties": {"textures": [{"Signature": "jGgDnHSDXubnjL+oqQM4LJB/A+cJbpt86o/ZTLPHI60X68DBnCWn5EVUe+MqGpoAH6Xk64tZzDvK1sKKHNLsA8eZcJYMiu4xaJLCCI7dyOyfOGS0fkKaMpno/x8TKYliy6qEreZ87ZuBSrLQq2kVATyghqa1TNd4T/GicAWxwCMkjzUqP7BEGuBaVIMmMSUv0cg8ywLTJbB4TG4O9T0tsgw7pp3UNl6LXDLQrRFfxiNuYjeZGNt57akh8oun6BUIDB3CHhZmtslWt169I4P+6g/PFoajp7P2aINRT8P8+KDJS064UtuY15ymvLTlnpCfa/R/e5WIlPDSSkAtbInYBxod0efTtOH5KbHJhaiTpWpe+MVlsNWPtAZ9oEvpeftS0B4IH74+5LtWg52SKaTTmvJWykFzQ/tYtIVYCmeJZdEzOAlVNPLc0Byn6Y9cKghD6iiAJOm6PrKlXptMeBGFKM2YvxPYuuCV/7FpeCbHgIQvbdHia5r1SR1ynQCB3VTz3RCTzc2mU4t5rByBGVnEYyuLErGfpZ6kMKjSa8Le3gAiGWb2aof45s1v3HMvHaSxXLcoUpO9r8S5UJr32BQN4qo3rZ1CZvNmzcjI4BcytRcpo8nKo1T2RjJFA+qYE8Kl73Lfmm/lR9j5F1cvUcbdgTivZJUGcYOTaYQMDc4GvHU=", "Value": "ewogICJ0aW1lc3RhbXAiIDogMTYwMjAzNzQ0MTk0MSwKICAicHJvZmlsZUlkIiA6ICJhMjk1ODZmYmU1ZDk0Nzk2OWZjOGQ4ZGE0NzlhNDNlZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJWaWVydGVsdG9hc3RpaWUiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTU3YjM1NGNlOWJmOGRiMGE3ZWQyYWZjNzllMjdmMjhjM2NjYWFhZjJjNDYwYTUxOTkzY2FjMmIwNTY0ZWY2MCIKICAgIH0KICB9Cn0="}]}}, "display": {"Lore": ["§7Increases the regrowth rate of", "§7nearby crops on the public islands,", "§7regrowing an extra crop every §a3", "§a§7seconds.", "", "§a§lUNCOMMON ACCESSORY"], "Name": "§aFarmer Orb"}, "ExtraAttributes": {"id": "FARMER_ORB", "uuid": "aa1f61c7-8a35-49bb-8943-62cedada8713", "timestamp": 1765799109760}}, "Damage": 3}]}');
CREATE TABLE item_enchants (price_id INTEGER, enchant TEXT, level INTEGER);
CREATE TABLE item_attributes (price_id INTEGER, attribute TEXT, value INTEGER);
CREATE TABLE item_rarities (price_id INTEGER, rarity TEXT);
CREATE TABLE item_reforges (price_id INTEGER, reforge TEXT);
CREATE TABLE item_gems (price_id INTEGER, gem TEXT, quality INTEGER);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('pricesV2',1);
CREATE INDEX idx_pricesV2_itemkey ON pricesV2(itemkey);
CREATE INDEX idx_pricesV2_timestamp ON pricesV2(timestamp);
COMMIT;
